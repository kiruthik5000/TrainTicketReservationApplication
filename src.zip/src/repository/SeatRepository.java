package repository;

import dto.SeatUpdateRequestDto;
import exception.DataBaseException;
import model.Seat;
import model.SeatStatus;

import java.util.List;

public interface SeatRepository {
    List<Seat> getAvailableSeats(int trainId, int mask) throws DataBaseException;
    Seat getSeatById(int seatId) throws DataBaseException;
    void updateAllSeatStatus(List<SeatUpdateRequestDto> updateRequestDtos, SeatStatus status);
}
