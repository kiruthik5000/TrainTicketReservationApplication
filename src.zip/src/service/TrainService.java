
package service;

import dto.MultiHopTrainDto;
import dto.SimpleTrainDto;
import exception.DataBaseException;
import model.Station;
import model.Train;
import repository.Implementation.InMemory.InMemoryStationRepository;
import repository.Implementation.InMemory.InMemoryTrainRepository;
import repository.StationRepository;
import repository.TrainRepository;

import java.util.*;

class Node {
    String curStationCode;
    Node parent;
    Integer trainUsedToReach;

    Node(String curStationCode, Node parent, Integer trainUsedToReach) {
        this.curStationCode = curStationCode;
        this.parent = parent;
        this.trainUsedToReach = trainUsedToReach;
    }
}

public class TrainService {

    private final StationRepository stationRepository;
    private final TrainRepository trainRepository;

    private final Map<String, Set<Integer>> stationTrainMap;
    private final Map<Integer, List<String>> trainStationMap;

    public TrainService(TrainRepository trainRepository, StationRepository stationRepository) {
        this.stationRepository = stationRepository;
        this.trainRepository = trainRepository;

        this.trainStationMap = stationRepository.getTrainStationMap();

        stationTrainMap = new HashMap<>();

        for (Map.Entry<Integer, List<String>> entry : trainStationMap.entrySet()) {
            int train = entry.getKey();
            for (String station : entry.getValue()) {
                stationTrainMap
                        .computeIfAbsent(
                                station,
                                k -> new HashSet<>()
                        )
                        .add(train);
            }
        }
    }

    public MultiHopTrainDto searchTrains(String from, String to) throws DataBaseException {

        Station src = stationRepository.getStationByCode(from);
        Station dest = stationRepository.getStationByCode(to);

        if (src == null || dest == null) {
            return null;
        }

        MultiHopTrainDto dto = new MultiHopTrainDto();

        if (from.equals(to)) {
            return dto;
        }

        Node result = searchTrainHops(from, to);

        if (result == null) {
            return null;
        }

        List<Node> path = new ArrayList<>();

        for (Node cur = result; cur.parent != null; cur = cur.parent) {
            path.add(cur);
        }

        Collections.reverse(path);

        for (Node node : path) {
            Train train = trainRepository.getTrainById(
                    node.trainUsedToReach
            );

            Station segmentFrom = stationRepository.getStationByCode(
                    node.parent.curStationCode
            );

            Station segmentTo = stationRepository.getStationByCode(
                    node.curStationCode
            );

            dto.addTrainDto(
                    new SimpleTrainDto(train, segmentFrom, segmentTo)
            );
        }

        return dto;
    }

    public Node searchTrainHops(String src, String dest) {

        if (src.equals(dest)) {
            return new Node(src, null, null);
        }

        Queue<Node> queue = new LinkedList<>();
        Set<String> visitedStations = new HashSet<>();
        Set<Integer> visitedTrains = new HashSet<>();

        queue.offer(new Node(src, null, null));
        visitedStations.add(src);

        while (!queue.isEmpty()) {
            Node cur = queue.poll();

            for (int trainId : stationTrainMap.getOrDefault(cur.curStationCode, new HashSet<>())) {
                if (!visitedTrains.add(trainId)) {
                    continue;
                }
                for (String nextStation : trainStationMap.getOrDefault(trainId, new ArrayList<>())) {
                    if (!visitedStations.add(nextStation)) {
                        continue;
                    }
                    Node next = new Node(nextStation, cur, trainId);

                    if (nextStation.equals(dest)) {
                        return next;
                    }
                    queue.offer(next);
                }
            }
        }

        return null;
    }

    public static void main(String[] args) throws DataBaseException {
        TrainRepository tr = new InMemoryTrainRepository();
        StationRepository sr = new InMemoryStationRepository();
        TrainService ts = new TrainService(tr, sr);
        System.out.println(ts.searchTrains("A", "Z"));
    }
}
